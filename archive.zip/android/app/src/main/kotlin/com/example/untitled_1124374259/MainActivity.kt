package com.example.untitled_1124374259

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
